// content.js

// Wstrzykiwanie stylu CSS do spłaszczenia wierszy YouTube, co pozwala na sortowanie flexboxem globalnie
const hiderStyle = document.createElement('style');
hiderStyle.textContent = `
  .youtube-hider-active ytd-rich-grid-row, 
  .youtube-hider-active ytd-rich-grid-row > #contents {
    display: contents !important;
  }
`;
(document.head || document.documentElement).appendChild(hiderStyle);

/**
 * Funkcja przeliczająca czas na minuty.
 * Zwraca -1, jeśli nie znaleziono informacji o czasie publikacji.
 */
function calculateRank(item) {
    const text = item.textContent.toLowerCase();
    
    // 1. Sprawdzanie czy to Sponsorowane lub Reklama (często nie mają czasu)
    if (item.querySelector('#ad-badge, .ytd-ad-slot-renderer') || text.includes('sponsorowane') || text.includes('sponsored')) {
        return -1;
    }

    // 2. Szukamy tekstu dotyczącego czasu (temu / ago)
    const metadataSelectors = [
        '#metadata-line span.inline-metadata-item',
        '#metadata-line span',
        '.yt-core-attributed-string', // nowy standard renderowania tekstu na YT
        '.yt-lockup-metadata-view-model__metadata span',
        '.yt-content-metadata-view-model__metadata-row span'
    ];
    
    let timeText = "";
    
    // Najpierw szukamy w konkretnych znacznikach HTML
    for (const selector of metadataSelectors) {
        const elements = item.querySelectorAll(selector);
        for (const el of elements) {
            const txt = el.textContent.toLowerCase();
            if (txt.includes('temu') || txt.includes('ago')) {
                timeText = txt;
                break;
            }
        }
        if (timeText) break;
    }

    // 3. FUNKCJA RATUNKOWA (Fallback) - szukaj w całym widocznym tekście kafelka
    if (!timeText) {
        const visibleText = item.innerText || "";
        const lines = visibleText.toLowerCase().split('\n');
        for (const line of lines) {
            if (line.includes('temu') || line.includes('ago')) {
                timeText = line;
                break;
            }
        }
    }

    // JEŚLI NIE ZNALEZIONO CZASU -> Zwróć -1 (do ukrycia)
    if (!timeText) return -1;

    // Obsługiwane jednostki czasu (PL i EN)
    const timeUnits = {
        'minutę': 1, 'minuty': 1, 'minut': 1, 'minute': 1, 'minutes': 1, 'mins': 1,
        'godzinę': 60, 'godziny': 60, 'godzin': 60, 'hour': 60, 'hours': 60,
        'dzień': 1440, 'dni': 1440, 'day': 1440, 'days': 1440,
        'tydzień': 10080, 'tygodnie': 10080, 'tygodni': 10080, 'tyg.': 10080, 'week': 10080, 'weeks': 10080,
        'miesiąc': 43200, 'miesiące': 43200, 'miesięcy': 43200, 'mies.': 43200, 'month': 43200, 'months': 43200,
        'rok': 525600, 'lata': 525600, 'lat': 525600, 'year': 525600, 'years': 525600
    };

    // Sortujemy klucze od najdłuższych do najkrótszych, aby uniknąć błędnych dopasowań (np. "godzin" przed "godziny")
    const sortedUnits = Object.keys(timeUnits).sort((a, b) => b.length - a.length);

    for (const unit of sortedUnits) {
        if (timeText.includes(unit)) {
            // Szukamy liczby stojącej bezpośrednio przed jednostką czasu (np. "19 godzin")
            // Ignoruje to liczbę wyświetleń stojącą na początku tekstu (np. "137 wyświetleń")
            const regex = new RegExp(`(\\d+)\\s*${unit}`, 'i');
            const match = timeText.match(regex);
            
            if (match) {
                const value = parseInt(match[1], 10);
                return value * timeUnits[unit];
            } else {
                // Jeśli jednostka występuje, ale nie ma przed nią liczby (np. "godzinę temu", "rok temu")
                return 1 * timeUnits[unit];
            }
        }
    }

    return -1; // Jeśli jednostka czasu nie jest obsługiwana
}

function processYouTubeHider() {
    // Precyzyjny selektor nadrzędny (> #contents), aby uniknąć wewnętrznych kontenerów wierszy
    const gridContainer = document.querySelector('ytd-rich-grid-renderer > #contents');
    if (!gridContainer) return;

    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], function (result) {
        const isEnabled = result.pluginEnabled !== false;
        
        // Pobieramy wszystkie kafelki z filmami oraz sekcjami specjalnymi
        const items = gridContainer.querySelectorAll('ytd-rich-item-renderer, ytd-rich-section-renderer');
        let hiddenCount = 0;

        if (!isEnabled) {
            // Przywracamy domyślne style i usuwamy klasę aktywności
            document.documentElement.classList.remove('youtube-hider-active');
            gridContainer.style.removeProperty('display');
            gridContainer.style.removeProperty('flex-wrap');
            items.forEach(item => {
                item.style.removeProperty('display');
                item.style.removeProperty('order');
                item.style.removeProperty('width');
                item.style.removeProperty('margin');
            });
            return;
        }

        // Dodajemy klasę, która aktywuje wstrzyknięty styl display: contents na wierszach
        document.documentElement.classList.add('youtube-hider-active');

        // Wymuszenie układu Flexbox na nadrzędnym kontenerze
        gridContainer.style.setProperty('display', 'flex', 'important');
        gridContainer.style.setProperty('flex-wrap', 'wrap', 'important');

        const keywordSettings = result.keywordSettings || {};
        const activeKeywords = Object.keys(keywordSettings).filter(k => keywordSettings[k]);
        
        // Bezpieczne pobranie liczby elementów w rzędzie
        const rawItemsPerRow = getComputedStyle(gridContainer).getPropertyValue('--ytd-rich-grid-items-per-row');
        const itemsPerRow = parseInt(rawItemsPerRow, 10) || 4;

        items.forEach(item => {
            const textContent = item.textContent.toLowerCase();
            const rank = calculateRank(item);
            
            let shouldHide = false;

            // KROK 1: Ukryj jeśli nie ma czasu (rank === -1)
            if (rank === -1) {
                shouldHide = true;
            } 
            // KROK 2: Ukryj jeśli pasuje do słów kluczowych
            else if (activeKeywords.some(kw => textContent.includes(kw.toLowerCase()))) {
                shouldHide = true;
            }

            if (shouldHide) {
                item.style.setProperty('display', 'none', 'important');
                hiddenCount++;
            } else {
                item.style.setProperty('display', 'block', 'important');
                item.style.setProperty('order', rank, 'important'); // Układanie od najmniejszej wartości (najnowsze)

                // Indywidualne dopasowanie wymiarów kafelków vs sekcji (np. Shorts)
                if (item.tagName.toLowerCase() === 'ytd-rich-item-renderer') {
                    item.style.setProperty('width', `calc(100% / ${itemsPerRow} - 16px)`, 'important');
                    item.style.setProperty('margin', '0 8px 24px 8px', 'important');
                } else {
                    // Dla sekcji specjalnych dajemy pełną szerokość
                    item.style.setProperty('width', '100%', 'important');
                    item.style.setProperty('margin', '0 0 24px 0', 'important');
                }
            }
        });

        chrome.runtime.sendMessage({ action: 'updateBadge', count: hiddenCount });
    });
}

// Obserwator zmian (dla dynamicznego ładowania kolejnych filmów)
const observer = new MutationObserver((mutations) => {
    if (mutations.some(m => m.addedNodes.length > 0)) {
        clearTimeout(window.hiderTimer);
        window.hiderTimer = setTimeout(processYouTubeHider, 400);
    }
});

function init() {
    const container = document.querySelector('ytd-rich-grid-renderer > #contents');
    if (container) {
        processYouTubeHider();
        observer.observe(container, { childList: true });
    } else {
        setTimeout(init, 1000);
    }
}

init();
window.addEventListener('yt-navigate-finish', init);

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'refresh') processYouTubeHider();
});