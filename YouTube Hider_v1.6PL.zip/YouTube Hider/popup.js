// popup.js

const keywords = [
    "minutę", "minuty", "minut", "godzinę", "godziny", "godzin",
    "dzień", "dni", "tydzień", "tygodnie", "tygodni", "tyg.",
    "miesiąc", "miesiące", "miesięcy", "mies.", "rok", "lata", "lat", "Sponsorowane"
];

document.addEventListener('DOMContentLoaded', function () {
    const pluginCheckbox = document.getElementById('pluginCheckbox');
    const keywordCheckboxesDiv = document.getElementById('keywordCheckboxes');

    // Wyczyść wiadomość o ładowaniu
    keywordCheckboxesDiv.innerHTML = '';

    // Utwórz checkboxy dla każdego słowa kluczowego
    keywords.forEach(keyword => {
        const label = document.createElement('label');
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = `keyword-${keyword}`;
        label.appendChild(checkbox);
        label.appendChild(document.createTextNode(` ${keyword}`));
        keywordCheckboxesDiv.appendChild(label);
    });

    // Załaduj zapisane ustawienia
    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], function (result) {
        pluginCheckbox.checked = result.pluginEnabled !== false;
        const keywordSettings = result.keywordSettings || {};

        keywords.forEach(keyword => {
            const checkbox = document.getElementById(`keyword-${keyword}`);
            checkbox.checked = keywordSettings[keyword] !== false; // Domyślnie true, jeśli nie ustawiono
        });
    });

    // Zapisz ustawienia, gdy zmieni się główny checkbox pluginu
    pluginCheckbox.addEventListener('change', function () {
        const isEnabled = pluginCheckbox.checked;
        // Zapisanie ustawienia automatycznie wywoła listener `storage.onChanged` w background.js
        chrome.storage.local.set({ 'pluginEnabled': isEnabled });
        refreshPage();
    });

    // Zapisz ustawienia, gdy zmieni się którykolwiek checkbox słowa kluczowego
    keywords.forEach(keyword => {
        const checkbox = document.getElementById(`keyword-${keyword}`);
        checkbox.addEventListener('change', function () {
            chrome.storage.local.get('keywordSettings', function (result) {
                const keywordSettings = result.keywordSettings || {};
                keywordSettings[keyword] = checkbox.checked;
                chrome.storage.local.set({ 'keywordSettings': keywordSettings });
                refreshPage();
            });
        });
    });
});

function refreshPage() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        // Upewnij się, że wysyłasz wiadomość tylko do kart YouTube
        if (tabs[0] && tabs[0].id && tabs[0].url.includes("youtube.com")) {
            chrome.tabs.sendMessage(tabs[0].id, { action: 'refresh' });
        }
    });
}