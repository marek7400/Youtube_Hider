// background.js

// Funkcja ustawiająca domyślne wartości przy instalacji rozszerzenia
function setDefaultSettings() {
  const defaultKeywords = [
    "minutę", "minuty", "minut", "godzinę", "godziny", "godzin",
    "dzień", "dni", "tydzień", "tygodnie", "tygodni",
    "miesiąc", "miesiące", "miesięcy", "rok", "lata", "lat", "Sponsorowane"
  ];

  const defaultKeywordSettings = {};
  defaultKeywords.forEach(keyword => {
    // Domyślnie wszystkie słowa kluczowe są włączone
    defaultKeywordSettings[keyword] = true;
  });

  chrome.storage.local.set({
    pluginEnabled: true, // Domyślnie włączony
    keywordSettings: defaultKeywordSettings
  });
}

// Nasłuchuj zdarzenia onInstalled, aby ustawić domyślne wartości
chrome.runtime.onInstalled.addListener((details) => {
  console.log("YouTube Hider installed or updated.");
  if (details.reason === 'install') {
    setDefaultSettings();
    console.log("Default settings have been initialized.");
  }
});

// Nasłuchuj na wiadomości od content.js, aby aktualizować licznik
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (sender.tab && sender.tab.id && request.action === 'updateBadge') {
    const tabId = sender.tab.id;
    chrome.storage.local.get('pluginEnabled', (result) => {
      const isEnabled = result.pluginEnabled !== false;
      // Przekazujemy aktualny stan do funkcji aktualizującej plakietkę
      updateBadge(tabId, request.count, isEnabled);
    });
  }
});

// NOWOŚĆ: Nasłuchuj na zmiany w storage, aby natychmiast reagować na włączenie/wyłączenie
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local' && changes.pluginEnabled) {
    const isEnabled = changes.pluginEnabled.newValue;
    // Znajdź aktywną kartę YouTube i zaktualizuj jej plakietkę
    chrome.tabs.query({ active: true, url: "*://*.youtube.com/*" }, (tabs) => {
      if (tabs.length > 0) {
        const tabId = tabs[0].id;
        // Aktualizujemy kolor i tekst, resetując licznik (zostanie on zaktualizowany po odświeżeniu)
        updateBadge(tabId, 0, isEnabled);
      }
    });
  }
});

// Funkcja pomocnicza do aktualizacji plakietki
function updateBadge(tabId, count, isEnabled) {
  // Zawsze ustawiamy kolor tekstu na biały
  chrome.action.setBadgeTextColor({ tabId: tabId, color: '#FFFFFF' });

  if (isEnabled) {
    // Plugin włączony - kolor zielony
    chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: '#4CAF50' }); // Zielony
    const text = count > 0 ? String(count) : '';
    chrome.action.setBadgeText({ tabId: tabId, text: text });
  } else {
    // Plugin wyłączony - kolor czerwony, tekst "OFF"
    chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: '#F44336' }); // Czerwony
    chrome.action.setBadgeText({ tabId: tabId, text: 'OFF' });
  }
}

// Czyść plakietkę, gdy użytkownik opuszcza stronę YouTube
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && tab.url && !tab.url.includes("youtube.com")) {
    chrome.action.setBadgeText({ tabId: tabId, text: '' });
  }
});