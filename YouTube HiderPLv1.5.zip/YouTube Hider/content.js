// content.js

/**
 * Funkcja przeliczająca czas na minuty.
 * Zwraca -1, jeśli nie znaleziono informacji o czasie publikacji.
 */
function calculateRank(item) {
    const text = item.textContent.toLowerCase();
    
    // 1. Sprawdzanie czy to Sponsorowane lub Reklama (często nie mają czasu)
    if (item.querySelector('#ad-badge, .ytd-ad-slot-renderer') || text.includes('sponsorowane') || text.includes('sponsored')) {
        return -1;
    }

    // 2. Szukamy tekstu dotyczącego czasu (temu / ago)
    // Zaktualizowane selektory pod nową strukturę YouTube
    const metadataSelectors = [
        '#metadata-line span.inline-metadata-item',
        '#metadata-line span',
        '.yt-core-attributed-string', // NOWOŚĆ: nowy standard renderowania tekstu na YT
        '.yt-lockup-metadata-view-model__metadata span',
        '.yt-content-metadata-view-model__metadata-row span'
    ];
    
    let timeText = "";
    
    // Najpierw szukamy w konkretnych znacznikach HTML
    for (const selector of metadataSelectors) {
        const elements = item.querySelectorAll(selector);
        for (const el of elements) {
            const txt = el.textContent.toLowerCase();
            // Szukamy frazy sugerującej czas publikacji
            if (txt.includes('temu') || txt.includes('ago')) {
                timeText = txt;
                break;
            }
        }
        if (timeText) break;
    }

    // 3. FUNKCJA RATUNKOWA (Fallback) - Jeśli YouTube znów zmieni znaczniki, szukaj w całym widocznym tekście
    if (!timeText) {
        const visibleText = item.innerText || "";
        const lines = visibleText.toLowerCase().split('\n');
        for (const line of lines) {
            if (line.includes('temu') || line.includes('ago')) {
                timeText = line;
                break;
            }
        }
    }

    // JEŚLI NIE ZNALEZIONO CZASU -> Zwróć -1 (do ukrycia)
    if (!timeText) return -1;

    // Obsługiwane jednostki czasu (PL i EN dla bezpieczeństwa)
    const timeUnits = {
        'minut': 1, 'minutę': 1, 'minuty': 1, 'minute': 1, 'minutes': 1, 'mins': 1,
        'godzin': 60, 'godzinę': 60, 'godziny': 60, 'hour': 60, 'hours': 60,
        'dzień': 1440, 'dni': 1440, 'day': 1440, 'days': 1440,
        'tydzień': 10080, 'tygodnie': 10080, 'tygodni': 10080, 'week': 10080, 'weeks': 10080,
        'miesiąc': 43200, 'miesiące': 43200, 'miesięcy': 43200, 'month': 43200, 'months': 43200,
        'rok': 525600, 'lata': 525600, 'lat': 525600, 'year': 525600, 'years': 525600
    };

    for (const unit in timeUnits) {
        if (timeText.includes(unit)) {
            const match = timeText.match(/\d+/);
            const value = match ? parseInt(match[0], 10) : 1; // np. "godzinę temu" = 1
            return value * timeUnits[unit];
        }
    }

    return -1; // Jeśli jednostka czasu nie jest obsługiwana
}

function processYouTubeHider() {
    const gridContainer = document.querySelector('ytd-rich-grid-renderer #contents');
    if (!gridContainer) return;

    // Wymuszenie Flexbox dla poprawnego sortowania 'order'
    gridContainer.style.display = 'flex';
    gridContainer.style.flexWrap = 'wrap';

    const items = gridContainer.querySelectorAll('ytd-rich-item-renderer, ytd-rich-section-renderer');

    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], function (result) {
        const isEnabled = result.pluginEnabled !== false;
        let hiddenCount = 0;

        if (!isEnabled) {
            gridContainer.style.display = '';
            items.forEach(item => {
                item.style.display = '';
                item.style.order = '';
                item.style.width = '';
            });
            return;
        }

        const keywordSettings = result.keywordSettings || {};
        const activeKeywords = Object.keys(keywordSettings).filter(k => keywordSettings[k]);
        const itemsPerRow = getComputedStyle(gridContainer).getPropertyValue('--ytd-rich-grid-items-per-row') || 4;

        items.forEach(item => {
            const textContent = item.textContent.toLowerCase();
            const rank = calculateRank(item);
            
            let shouldHide = false;

            // KROK 1: Ukryj jeśli nie ma czasu (rank === -1) np. Live, Premiery bez czasu itp.
            if (rank === -1) {
                shouldHide = true;
            } 
            // KROK 2: Ukryj jeśli pasuje do słów kluczowych wybranych przez użytkownika
            else if (activeKeywords.some(kw => textContent.includes(kw.toLowerCase()))) {
                shouldHide = true;
            }

            if (shouldHide) {
                item.style.display = 'none';
                hiddenCount++;
            } else {
                // Wyświetlanie i sortowanie
                item.style.display = 'block';
                item.style.width = `calc(100% / ${itemsPerRow} - 16px)`;
                item.style.margin = '0 8px 24px 8px';
                item.style.order = rank; // Sortowanie po wieku
            }
        });

        chrome.runtime.sendMessage({ action: 'updateBadge', count: hiddenCount });
    });
}

// Obserwator zmian (dla dynamicznego ładowania)
const observer = new MutationObserver((mutations) => {
    if (mutations.some(m => m.addedNodes.length > 0)) {
        clearTimeout(window.hiderTimer);
        window.hiderTimer = setTimeout(processYouTubeHider, 400);
    }
});

function init() {
    const container = document.querySelector('ytd-rich-grid-renderer #contents');
    if (container) {
        processYouTubeHider();
        observer.observe(container, { childList: true });
    } else {
        setTimeout(init, 1000);
    }
}

init();
window.addEventListener('yt-navigate-finish', init);

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'refresh') processYouTubeHider();
});