// background.js

// Function to set default values upon extension installation
function setDefaultSettings() {
  const defaultKeywords = [
    "minute", "minutes", "hour", "hours", "day", "days", 
    "week", "weeks", "month", "months", "year", "years", "Sponsored"
  ];

  const defaultKeywordSettings = {};
  defaultKeywords.forEach(keyword => {
    // By default, all keywords are enabled (checked)
    defaultKeywordSettings[keyword] = true;
  });

  chrome.storage.local.set({
    pluginEnabled: true, // Enabled by default
    keywordSettings: defaultKeywordSettings
  });
}

// Listen for the onInstalled event to set default values
chrome.runtime.onInstalled.addListener((details) => {
  console.log("YouTube Hider installed or updated.");
  if (details.reason === 'install') {
    setDefaultSettings();
    console.log("Default settings have been initialized.");
  }
});

// Listen for messages from content.js to update the badge counter
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (sender.tab && sender.tab.id && request.action === 'updateBadge') {
    const tabId = sender.tab.id;
    chrome.storage.local.get('pluginEnabled', (result) => {
      const isEnabled = result.pluginEnabled !== false;
      updateBadge(tabId, request.count, isEnabled);
    });
  }
});

// Update badge immediately when settings change in storage
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local' && changes.pluginEnabled) {
    const isEnabled = changes.pluginEnabled.newValue;
    chrome.tabs.query({ active: true, url: "*://*.youtube.com/*" }, (tabs) => {
      if (tabs.length > 0) {
        const tabId = tabs[0].id;
        updateBadge(tabId, 0, isEnabled);
      }
    });
  }
});

// Helper function to update the extension badge (icon text)
function updateBadge(tabId, count, isEnabled) {
  chrome.action.setBadgeTextColor({ tabId: tabId, color: '#FFFFFF' });

  if (isEnabled) {
    // Plugin enabled - Green color
    chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: '#4CAF50' }); 
    const text = count > 0 ? String(count) : '';
    chrome.action.setBadgeText({ tabId: tabId, text: text });
  } else {
    // Plugin disabled - Red color, text "OFF"
    chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: '#F44336' }); 
    chrome.action.setBadgeText({ tabId: tabId, text: 'OFF' });
  }
}

// Clear badge when leaving YouTube
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && tab.url && !tab.url.includes("youtube.com")) {
    chrome.action.setBadgeText({ tabId: tabId, text: '' });
  }
});