// content.js

/**
 * Calculates rank in minutes based on upload time.
 * Returns -1 if no time indicator is found (hides the video by default).
 */
function calculateRank(item) {
    const text = item.textContent.toLowerCase();
    
    // 1. Check for Sponsored/Ads (usually don't have time metadata)
    if (item.querySelector('#ad-badge') || text.includes('sponsored')) return -1;

    // 2. Look for metadata containing the time (e.g., "5 hours ago")
    const metadataSelectors = [
        '#metadata-line span.inline-metadata-item',
        '.yt-lockup-metadata-view-model__metadata span',
        '.yt-content-metadata-view-model__metadata-row span'
    ];
    
    let timeText = "";
    for (const selector of metadataSelectors) {
        const elements = item.querySelectorAll(selector);
        elements.forEach(el => {
            const txt = el.textContent.toLowerCase();
            // Look for the "ago" keyword which signifies publication time
            if (txt.includes('ago')) {
                timeText = txt;
            }
        });
        if (timeText) break;
    }

    // IF NO TIME FOUND -> Return -1 to hide (e.g., Live, Premiere, or Shorts shelf)
    if (!timeText) return -1;

    const timeUnits = {
        'minute': 1, 'minutes': 1,
        'hour': 60, 'hours': 60,
        'day': 1440, 'days': 1440,
        'week': 10080, 'weeks': 10080,
        'month': 43200, 'months': 43200,
        'year': 525600, 'years': 525600
    };

    for (const unit in timeUnits) {
        if (timeText.includes(unit)) {
            // Extract the number specifically from the time string (e.g., "2" from "2 hours ago")
            const match = timeText.match(/\d+/);
            const value = match ? parseInt(match[0], 10) : 1;
            return value * timeUnits[unit];
        }
    }

    return -1; 
}

function processYouTubeHider() {
    const gridContainer = document.querySelector('ytd-rich-grid-renderer #contents');
    if (!gridContainer) return;

    // Force Flexbox layout so CSS 'order' property works correctly for sorting
    gridContainer.style.display = 'flex';
    gridContainer.style.flexWrap = 'wrap';

    const items = gridContainer.querySelectorAll('ytd-rich-item-renderer, ytd-rich-section-renderer');

    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], function (result) {
        const isEnabled = result.pluginEnabled !== false;
        let hiddenCount = 0;

        if (!isEnabled) {
            // Reset styles if plugin is disabled
            gridContainer.style.display = '';
            items.forEach(item => {
                item.style.display = '';
                item.style.order = '';
                item.style.width = '';
            });
            chrome.runtime.sendMessage({ action: 'updateBadge', count: 0 });
            return;
        }

        const keywordSettings = result.keywordSettings || {};
        const activeKeywords = Object.keys(keywordSettings).filter(k => keywordSettings[k]);
        
        // Maintain the grid look by calculating item width
        const itemsPerRow = getComputedStyle(gridContainer).getPropertyValue('--ytd-rich-grid-items-per-row') || 4;

        items.forEach(item => {
            const textContent = item.textContent.toLowerCase();
            const rank = calculateRank(item);
            
            let shouldHide = false;

            // STEP 1: Hide if no valid time metadata was found
            if (rank === -1) {
                shouldHide = true;
            } 
            // STEP 2: Hide if it matches user-selected keywords
            else if (activeKeywords.some(kw => textContent.includes(kw.toLowerCase()))) {
                shouldHide = true;
            }

            if (shouldHide) {
                item.style.display = 'none';
                hiddenCount++;
            } else {
                // Display and Sort
                item.style.display = 'block';
                item.style.width = `calc(100% / ${itemsPerRow} - 16px)`;
                item.style.margin = '0 8px 24px 8px';
                item.style.order = rank; // Lower rank (newer) comes first
            }
        });

        chrome.runtime.sendMessage({ action: 'updateBadge', count: hiddenCount });
    });
}

// Observer for infinite scrolling
const observer = new MutationObserver((mutations) => {
    if (mutations.some(m => m.addedNodes.length > 0)) {
        clearTimeout(window.hiderTimer);
        window.hiderTimer = setTimeout(processYouTubeHider, 400);
    }
});

function init() {
    const container = document.querySelector('ytd-rich-grid-renderer #contents');
    if (container) {
        processYouTubeHider();
        observer.observe(container, { childList: true });
    } else {
        setTimeout(init, 1000);
    }
}

// Start initialization
init();

// Re-init on navigation (YouTube is a Single Page App)
window.addEventListener('yt-navigate-finish', init);

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'refresh') processYouTubeHider();
});