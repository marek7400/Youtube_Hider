// popup.js

const keywords = [
    "minute", "minutes", "hour", "hours", "day", "days", 
    "week", "weeks", "month", "months", "year", "years", "Sponsored"
];

document.addEventListener('DOMContentLoaded', function () {
    const pluginCheckbox = document.getElementById('pluginCheckbox');
    const keywordCheckboxesDiv = document.getElementById('keywordCheckboxes');

    keywordCheckboxesDiv.innerHTML = '';

    // Create checkboxes for each English keyword
    keywords.forEach(keyword => {
        const label = document.createElement('label');
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = `keyword-${keyword}`;
        label.appendChild(checkbox);
        label.appendChild(document.createTextNode(` ${keyword}`));
        keywordCheckboxesDiv.appendChild(label);
    });

    // Load saved settings
    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], function (result) {
        pluginCheckbox.checked = result.pluginEnabled !== false;
        const keywordSettings = result.keywordSettings || {};

        keywords.forEach(keyword => {
            const checkbox = document.getElementById(`keyword-${keyword}`);
            checkbox.checked = keywordSettings[keyword] !== false;
        });
    });

    // Save Master Switch setting
    pluginCheckbox.addEventListener('change', function () {
        chrome.storage.local.set({ 'pluginEnabled': pluginCheckbox.checked });
        refreshYouTube();
    });

    // Save individual Keyword settings
    keywords.forEach(keyword => {
        const checkbox = document.getElementById(`keyword-${keyword}`);
        checkbox.addEventListener('change', function () {
            chrome.storage.local.get('keywordSettings', function (result) {
                const keywordSettings = result.keywordSettings || {};
                keywordSettings[keyword] = checkbox.checked;
                chrome.storage.local.set({ 'keywordSettings': keywordSettings });
                refreshYouTube();
            });
        });
    });
});

function refreshYouTube() {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        if (tabs[0] && tabs[0].url.includes("youtube.com")) {
            chrome.tabs.sendMessage(tabs[0].id, { action: 'refresh' });
        }
    });
}