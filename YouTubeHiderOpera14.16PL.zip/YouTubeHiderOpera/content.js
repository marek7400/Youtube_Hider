const SCROLL_TICK_MS = 600; 
const MAX_STALE_ROUNDS = 12; 
const TARGET_VISIBLE_VIDEOS = 300; 

const keywords = ['minut', 'godzin', 'dzień', 'dni', 'tydzień', 'tygodni', 'tygodnie', 'miesiąc', 'miesięcy', 'rok', 'lat'];

let pluginEnabled = true;
let keywordSettings = {};
// DODANO: exhausted - flaga zapobiegająca nieskończonej pętli
let scroll = { running: false, id: 0, lastCount: 0, stale: 0, exhausted: false };
let globalVisibleCount = 0; 
let mainInterval;

function isContextValid() {
    try {
        return !!chrome.runtime.id;
    } catch (e) {
        return false;
    }
}

try {
    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], (res) => {
        if (res.pluginEnabled !== undefined) pluginEnabled = res.pluginEnabled;
        if (res.keywordSettings !== undefined) keywordSettings = res.keywordSettings;
    });

    chrome.storage.onChanged.addListener((changes) => {
        if (changes.pluginEnabled) pluginEnabled = changes.pluginEnabled.newValue;
        if (changes.keywordSettings) keywordSettings = changes.keywordSettings.newValue;
        applyHider();
    });
} catch (e) {}

function isAllowedPath() {
    const p = window.location.pathname;
    return p === '/' || p === '/feed/subscriptions';
}

function isLiveVideo(item) {
    if (item.querySelector('[overlay-style="LIVE"], [overlay-style="SHORTS"], [overlay-style="UPCOMING"]')) return true;
    if (item.querySelector('ytd-playlist-thumbnail')) return true; 
    return false;
}

function getSeconds(item) {
    if (isLiveVideo(item)) return -1; 

    const rawText = (item.textContent || '').toLowerCase();
    const ariaLabel = item.querySelector('#video-title')?.getAttribute('aria-label') || '';
    const fullText = rawText + ' ' + ariaLabel.toLowerCase();

    const unitMap = { 'sek': 1, 'min': 60, 'godz': 3600, 'wczoraj': 86400, 'dzie': 86400, 'dni': 86400, 'tyg': 604800, 'mie': 2592000, 'rok': 31536000, 'lat': 31536000 };
    
    for (let key in unitMap) {
        let regex = new RegExp('(?:(\\d+)\\s+)?' + key + '[a-ząćęłńóśźż.]*\\s*(?:temu|ago)', 'i');
        let match = fullText.match(regex);
        if (match) {
            return (match[1] ? parseInt(match[1], 10) : 1) * unitMap[key];
        }
    }
    
    return -1; 
}

function applyHider() {
    if (!isContextValid()) {
        if (mainInterval) clearInterval(mainInterval);
        return;
    }

    if (!isAllowedPath()) return;
    const grid = document.querySelector('ytd-rich-grid-renderer > #contents');
    if (!grid) return;

    const items = grid.querySelectorAll('ytd-rich-item-renderer');
    let hiddenCnt = 0, visibleCnt = 0;

    for (let i = 0; i < items.length; i++) {
        let item = items[i];
        let secs = getSeconds(item);
        let hide = (secs === -1);

        if (!hide && pluginEnabled) {
            for (let j = 0; j < keywords.length; j++) {
                let kw = keywords[j];
                if (keywordSettings[kw]) {
                    if (item.textContent.toLowerCase().includes(kw.substring(0, 3).toLowerCase())) { 
                        hide = true; 
                        break; 
                    }
                }
            }
        }

        if (hide) {
            item.classList.add('yth-hidden');
            hiddenCnt++;
        } else {
            item.classList.remove('yth-hidden');
            item.style.setProperty('order', String(secs), 'important');
            visibleCnt++;
        }
    }

    globalVisibleCount = visibleCnt;
    let badgeText = pluginEnabled ? (hiddenCnt > 0 ? String(hiddenCnt) : 'ON') : 'OFF';

    try {
        chrome.runtime.sendMessage({ action: 'updateBadge', text: badgeText });
    } catch (e) {}

    // ZMIANA: Skrypt odpali scrollowanie tylko, jeśli NIE JEST wyczerpany (exhausted)
    if (pluginEnabled && globalVisibleCount < TARGET_VISIBLE_VIDEOS && !scroll.running && !scroll.exhausted) {
        startAutoLoad();
    }
}

function startAutoLoad() {
    if (!isContextValid() || !isAllowedPath() || scroll.running) return;
    scroll.running = true;
    scroll.id++;
    scroll.stale = 0;
    scroll.lastCount = document.querySelectorAll('ytd-rich-item-renderer').length;
    scrollStep(scroll.id);
}

function scrollStep(id) {
    if (!isContextValid() || id !== scroll.id || !scroll.running) return;

    if (globalVisibleCount >= TARGET_VISIBLE_VIDEOS) {
        scroll.running = false;
        window.scrollTo(0, 0); 
        return;
    }

    let items = document.querySelectorAll('ytd-rich-item-renderer');
    
    const loader = document.querySelector('ytd-continuation-item-renderer');
    if (loader) {
        loader.scrollIntoView(false);
    } else {
        window.scrollTo(0, document.documentElement.scrollHeight);
    }

    window.scrollBy(0, -50);
    setTimeout(() => {
        if (!isContextValid()) return;
        window.scrollBy(0, 50);
    }, 50);

    if (items.length > scroll.lastCount) {
        scroll.lastCount = items.length;
        scroll.stale = 0;
        applyHider(); 
    } else {
        scroll.stale++;
    }

    // ZMIANA: Jeśli YouTube przestanie ładować filmy, włączamy bezpiecznik (exhausted = true)
    if (scroll.stale >= MAX_STALE_ROUNDS) {
        scroll.running = false;
        scroll.exhausted = true; // To zapobiega pętli!
        window.scrollTo(0, 0);
        return;
    }

    setTimeout(() => scrollStep(id), SCROLL_TICK_MS);
}

mainInterval = setInterval(applyHider, 1500);

window.addEventListener('yt-navigate-finish', () => {
    if (!isContextValid()) return;
    scroll.running = false; 
    scroll.exhausted = false; // Resetujemy bezpiecznik przy przejściu na inną stronę
    setTimeout(startAutoLoad, 1000);
});

setTimeout(startAutoLoad, 1500);