// Usunięto zbędne słowa z interfejsu wtyczki
const keywords = ['minut', 'godzin', 'dzień', 'dni', 'tydzień', 'tygodni', 'tygodnie', 'miesiąc', 'miesięcy', 'rok', 'lat'];

document.addEventListener('DOMContentLoaded', () => {
    const grid = document.getElementById('kwGrid');
    const masterToggle = document.getElementById('masterToggle');

    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], (res) => {
        let pluginEnabled = res.pluginEnabled !== undefined ? res.pluginEnabled : true;
        let keywordSettings = res.keywordSettings || {};

        updateToggleBtn(pluginEnabled);
        masterToggle.addEventListener('click', () => {
            pluginEnabled = !pluginEnabled;
            updateToggleBtn(pluginEnabled);
            chrome.storage.local.set({ pluginEnabled: pluginEnabled });
        });

        keywords.forEach(kw => {
            let label = document.createElement('label');
            let cb = document.createElement('input');
            cb.type = 'checkbox';
            cb.checked = !!keywordSettings[kw];
            
            cb.addEventListener('change', (e) => {
                keywordSettings[kw] = e.target.checked;
                chrome.storage.local.set({ keywordSettings: keywordSettings });
            });

            label.appendChild(cb);
            label.appendChild(document.createTextNode(kw));
            grid.appendChild(label);
        });
    });

    function updateToggleBtn(isEnabled) {
        masterToggle.textContent = isEnabled ? 'WŁĄCZONY' : 'WYŁĄCZONY';
        masterToggle.className = isEnabled ? 'toggle-btn btn-on' : 'toggle-btn btn-off';
    }
});