chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'updateBadge' && sender.tab) {
        chrome.action.setBadgeText({ 
            text: request.text, 
            tabId: sender.tab.id 
        });
        
        let color = request.text === 'OFF' ? '#FF0000' : '#FFC107';
        chrome.action.setBadgeBackgroundColor({ 
            color: color, 
            tabId: sender.tab.id 
        });
    }
});