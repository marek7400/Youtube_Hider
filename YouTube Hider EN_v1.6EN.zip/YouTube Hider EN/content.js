// content.js

// Inject CSS style to "flatten" YouTube's row containers.
// display: contents makes ytd-rich-grid-row layout-invisible, 
// allowing all video items to behave as direct children of the parent Flexbox container.
const hiderStyle = document.createElement('style');
hiderStyle.textContent = `
  .youtube-hider-active ytd-rich-grid-row, 
  .youtube-hider-active ytd-rich-grid-row > #contents {
    display: contents !important;
  }
`;
(document.head || document.documentElement).appendChild(hiderStyle);

/**
 * Calculates time into minutes for sorting purposes.
 * Returns -1 if no publication time info is found (e.g., Live streams, Ads).
 */
function calculateRank(item) {
    const text = item.textContent.toLowerCase();
    
    // 1. Check if it's Sponsored or an Ad (they usually lack standard upload time)
    if (item.querySelector('#ad-badge, .ytd-ad-slot-renderer') || text.includes('sponsored') || text.includes('ad')) {
        return -1;
    }

    // 2. Look for text indicating time ("ago")
    // Updated selectors for the new YouTube layout
    const metadataSelectors = [
        '#metadata-line span.inline-metadata-item',
        '#metadata-line span',
        '.yt-core-attributed-string', // NEW: current standard for rendering text on YT
        '.yt-lockup-metadata-view-model__metadata span',
        '.yt-content-metadata-view-model__metadata-row span'
    ];
    
    let timeText = "";
    
    // Search inside specific HTML tags first
    for (const selector of metadataSelectors) {
        const elements = item.querySelectorAll(selector);
        for (const el of elements) {
            const txt = el.textContent.toLowerCase();
            // Look for the phrase suggesting publication time
            if (txt.includes('ago')) {
                timeText = txt;
                break;
            }
        }
        if (timeText) break;
    }

    // 3. FALLBACK - If YouTube changes tags again, search all visible text
    if (!timeText) {
        const visibleText = item.innerText || "";
        const lines = visibleText.toLowerCase().split('\n');
        for (const line of lines) {
            if (line.includes('ago')) {
                timeText = line;
                break;
            }
        }
    }

    // IF NO TIME FOUND -> Return -1 (to be hidden)
    if (!timeText) return -1;

    // Supported English time units
    const timeUnits = {
        'second': 1, 'seconds': 1, // Usually fresh uploads, treated as 1 min to stay at top
        'minute': 1, 'minutes': 1, 'min': 1, 'mins': 1,
        'hour': 60, 'hours': 60, 'hr': 60, 'hrs': 60,
        'day': 1440, 'days': 1440,
        'week': 10080, 'weeks': 10080,
        'month': 43200, 'months': 43200, 'mo': 43200, 'mos': 43200,
        'year': 525600, 'years': 525600, 'yr': 525600, 'yrs': 525600
    };

    // Sort time units from longest to shortest to avoid partial matches (e.g. "hour" before "hours")
    const sortedUnits = Object.keys(timeUnits).sort((a, b) => b.length - a.length);

    for (const unit of sortedUnits) {
        if (timeText.includes(unit)) {
            // Specifically match the digits right before the unit (e.g. "19 hours")
            // This prevents grabbing unrelated numbers like "137 views"
            const regex = new RegExp(`(\\d+)\\s*${unit}`, 'i');
            const match = timeText.match(regex);
            
            if (match) {
                const value = parseInt(match[1], 10);
                return value * timeUnits[unit];
            } else {
                // If the unit is present but there's no numeric prefix (e.g., "an hour ago")
                return 1 * timeUnits[unit];
            }
        }
    }

    return -1; // If time unit is not supported
}

function processYouTubeHider() {
    // Precise selector to target the actual main grid contents container
    const gridContainer = document.querySelector('ytd-rich-grid-renderer > #contents');
    if (!gridContainer) return;

    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], function (result) {
        const isEnabled = result.pluginEnabled !== false;
        
        // Target both video items and section containers
        const items = gridContainer.querySelectorAll('ytd-rich-item-renderer, ytd-rich-section-renderer');
        let hiddenCount = 0;

        // If plugin is disabled, restore original layout styles
        if (!isEnabled) {
            document.documentElement.classList.remove('youtube-hider-active');
            gridContainer.style.removeProperty('display');
            gridContainer.style.removeProperty('flex-wrap');
            items.forEach(item => {
                item.style.removeProperty('display');
                item.style.removeProperty('order');
                item.style.removeProperty('width');
                item.style.removeProperty('margin');
            });
            return;
        }

        // Add class to activate display: contents for grid rows
        document.documentElement.classList.add('youtube-hider-active');

        // Force Flexbox styling on main container
        gridContainer.style.setProperty('display', 'flex', 'important');
        gridContainer.style.setProperty('flex-wrap', 'wrap', 'important');

        const keywordSettings = result.keywordSettings || {};
        const activeKeywords = Object.keys(keywordSettings).filter(k => keywordSettings[k]);
        
        // Safely parse items-per-row from CSS custom property
        const rawItemsPerRow = getComputedStyle(gridContainer).getPropertyValue('--ytd-rich-grid-items-per-row');
        const itemsPerRow = parseInt(rawItemsPerRow, 10) || 4;

        items.forEach(item => {
            const textContent = item.textContent.toLowerCase();
            const rank = calculateRank(item);
            
            let shouldHide = false;

            // STEP 1: Hide if there is no upload time (rank === -1)
            if (rank === -1) {
                shouldHide = true;
            } 
            // STEP 2: Hide if it matches keywords selected by the user
            else if (activeKeywords.some(kw => textContent.includes(kw.toLowerCase()))) {
                shouldHide = true;
            }

            if (shouldHide) {
                item.style.setProperty('display', 'none', 'important');
                hiddenCount++;
            } else {
                item.style.setProperty('display', 'block', 'important');
                item.style.setProperty('order', rank, 'important'); // Order ascending (youngest first)
                
                // Keep video cards aligned to grid while letting full sections span 100%
                if (item.tagName.toLowerCase() === 'ytd-rich-item-renderer') {
                    item.style.setProperty('width', `calc(100% / ${itemsPerRow} - 16px)`, 'important');
                    item.style.setProperty('margin', '0 8px 24px 8px', 'important');
                } else {
                    // For full sections (like Shorts shelves)
                    item.style.setProperty('width', '100%', 'important');
                    item.style.setProperty('margin', '0 0 24px 0', 'important');
                }
            }
        });

        // Send info to background.js to update the extension badge
        chrome.runtime.sendMessage({ action: 'updateBadge', count: hiddenCount });
    });
}

// Mutation Observer