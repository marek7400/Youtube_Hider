// content.js

let totalHiddenCount = 0;

function hideClosestRichItem() {
    console.log('hideClosestRichItem function called');
    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], function (result) {
        console.log('Plugin settings:', result);
        const pluginEnabled = result.pluginEnabled !== false;
        
        // Jeśli plugin jest wyłączony, upewnijmy się, że plakietka jest czysta
        if (!pluginEnabled) {
            console.log('Plugin is disabled');
            chrome.runtime.sendMessage({ action: 'updateBadge', count: 0 });
            return;
        }

        const keywordSettings = result.keywordSettings || {};
        const activeKeywords = Object.keys(keywordSettings).filter(keyword => keywordSettings[keyword]);
        console.log('Active keywords:', activeKeywords);

        let hiddenInThisRun = 0;
        const videoItems = document.querySelectorAll('ytd-rich-item-renderer');
        console.log('Found video items:', videoItems.length);
        
        videoItems.forEach(item => {
            if (item.style.display === 'none') {
                return;
            }

            const elementsToCheck = [
                item.querySelector('#metadata-line'),
                item.querySelector('p.ytd-badge-supported-renderer') // Dla "Sponsored"
            ];

            for (const element of elementsToCheck) {
                if (element) {
                    const textContent = element.textContent.toLowerCase();
                    if (activeKeywords.some(keyword => textContent.includes(keyword.toLowerCase()))) {
                        console.log('Matching keyword found, hiding item. Text:', textContent);
                        item.style.display = 'none';
                        hiddenInThisRun++;
                        break; // Znaleziono dopasowanie, przerwij pętlę dla tego itemu
                    }
                }
            }
        });

        if (hiddenInThisRun > 0) {
            totalHiddenCount += hiddenInThisRun;
            console.log(`Hid ${hiddenInThisRun} items in this run. Total hidden: ${totalHiddenCount}`);
        }

        // Wyślij wiadomość do background script, aby zaktualizować plakietkę
        chrome.runtime.sendMessage({ action: 'updateBadge', count: totalHiddenCount });
    });
}

// Wywołaj funkcję po załadowaniu strony
window.addEventListener('load', function () {
    console.log('Page loaded, calling hideClosestRichItem');
    hideClosestRichItem();

    // Wywołaj funkcję po kliknięciu na element ".yt-chip-cloud-chip-renderer.style-scope"
    document.addEventListener('click', function (event) {
        if (event.target.matches('.yt-chip-cloud-chip-renderer.style-scope')) {
            console.log('Chip clicked, calling hideClosestRichItem');
            setTimeout(hideClosestRichItem, 500);
        }
    });

    // Obserwator mutacji dla nowych elementów
    const observer = new MutationObserver(function (mutations) {
        let needsUpdate = false;
        for (const mutation of mutations) {
            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                 for (const node of mutation.addedNodes) {
                    if (node.nodeType === 1 && (node.matches('ytd-rich-item-renderer') || node.querySelector('ytd-rich-item-renderer'))) {
                        needsUpdate = true;
                        break;
                    }
                 }
            }
            if (needsUpdate) break;
        }

        if (needsUpdate) {
            console.log('New video items potentially added, calling hideClosestRichItem');
            clearTimeout(window.hideTimer);
            window.hideTimer = setTimeout(hideClosestRichItem, 300);
        }
    });

    // Konfiguracja obserwatora mutacji
    const config = { childList: true, subtree: true };
    const contentContainer = document.querySelector('ytd-page-manager');
    if (contentContainer) {
        observer.observe(contentContainer, config);
    } else {
        observer.observe(document.body, config); // Fallback
    }

    // Nasłuchuj komunikatów od popup.js
    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
        if (request.action === 'refresh') {
            console.log('Refresh request received, reloading page');
            location.reload(); // Odśwież stronę po zmianie ustawień
        }
    });
});