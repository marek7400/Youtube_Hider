// content.js

/**
 * Funkcja przeliczająca czas na minuty.
 * Zwraca -1, jeśli nie znaleziono informacji o czasie publikacji.
 */
function calculateRank(item) {
    const text = item.textContent.toLowerCase();
    
    // 1. Sprawdzanie czy to Sponsorowane (często nie mają czasu)
    if (item.querySelector('#ad-badge') || text.includes('sponsorowane')) return -1;

    // 2. Szukamy tekstu dotyczącego czasu (temu / ago)
    const metadataSelectors = [
        '#metadata-line span.inline-metadata-item',
        '.yt-lockup-metadata-view-model__metadata span',
        '.yt-content-metadata-view-model__metadata-row span'
    ];
    
    let timeText = "";
    for (const selector of metadataSelectors) {
        const elements = item.querySelectorAll(selector);
        elements.forEach(el => {
            const txt = el.textContent.toLowerCase();
            // Szukamy frazy sugerującej czas publikacji
            if (txt.includes('temu') || txt.includes('ago')) {
                timeText = txt;
            }
        });
        if (timeText) break;
    }

    // JEŚLI NIE ZNALEZIONO CZASU -> Zwróć -1 (do ukrycia)
    if (!timeText) return -1;

    const timeUnits = {
        'minut': 1, 'minutę': 1, 'minuty': 1, 'minute': 1,
        'godzin': 60, 'godzinę': 60, 'godziny': 60, 'hour': 60,
        'dzień': 1440, 'dni': 1440, 'day': 1440,
        'tydzień': 10080, 'tygodnie': 10080, 'tygodni': 10080, 'week': 10080,
        'miesiąc': 43200, 'miesiące': 43200, 'miesięcy': 43200, 'month': 43200,
        'rok': 525600, 'lata': 525600, 'lat': 525600, 'year': 525600
    };

    for (const unit in timeUnits) {
        if (timeText.includes(unit)) {
            const match = timeText.match(/\d+/);
            const value = match ? parseInt(match[0], 10) : 1;
            return value * timeUnits[unit];
        }
    }

    return -1; // Jeśli jednostka czasu nie jest obsługiwana
}

function processYouTubeHider() {
    const gridContainer = document.querySelector('ytd-rich-grid-renderer #contents');
    if (!gridContainer) return;

    // Wymuszenie Flexbox dla poprawnego sortowania 'order'
    gridContainer.style.display = 'flex';
    gridContainer.style.flexWrap = 'wrap';

    const items = gridContainer.querySelectorAll('ytd-rich-item-renderer, ytd-rich-section-renderer');

    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], function (result) {
        const isEnabled = result.pluginEnabled !== false;
        let hiddenCount = 0;

        if (!isEnabled) {
            gridContainer.style.display = '';
            items.forEach(item => {
                item.style.display = '';
                item.style.order = '';
                item.style.width = '';
            });
            return;
        }

        const keywordSettings = result.keywordSettings || {};
        const activeKeywords = Object.keys(keywordSettings).filter(k => keywordSettings[k]);
        const itemsPerRow = getComputedStyle(gridContainer).getPropertyValue('--ytd-rich-grid-items-per-row') || 4;

        items.forEach(item => {
            const textContent = item.textContent.toLowerCase();
            const rank = calculateRank(item);
            
            let shouldHide = false;

            // KROK 1: Ukryj jeśli nie ma czasu (rank === -1)
            if (rank === -1) {
                shouldHide = true;
            } 
            // KROK 2: Ukryj jeśli pasuje do słów kluczowych wybranych przez użytkownika
            else if (activeKeywords.some(kw => textContent.includes(kw.toLowerCase()))) {
                shouldHide = true;
            }

            if (shouldHide) {
                item.style.display = 'none';
                hiddenCount++;
            } else {
                // Wyświetlanie i sortowanie
                item.style.display = 'block';
                item.style.width = `calc(100% / ${itemsPerRow} - 16px)`;
                item.style.margin = '0 8px 24px 8px';
                item.style.order = rank;
            }
        });

        chrome.runtime.sendMessage({ action: 'updateBadge', count: hiddenCount });
    });
}

// Obserwator zmian (dla dynamicznego ładowania)
const observer = new MutationObserver((mutations) => {
    if (mutations.some(m => m.addedNodes.length > 0)) {
        clearTimeout(window.hiderTimer);
        window.hiderTimer = setTimeout(processYouTubeHider, 400);
    }
});

function init() {
    const container = document.querySelector('ytd-rich-grid-renderer #contents');
    if (container) {
        processYouTubeHider();
        observer.observe(container, { childList: true });
    } else {
        setTimeout(init, 1000);
    }
}

init();
window.addEventListener('yt-navigate-finish', init);

chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'refresh') processYouTubeHider();
});