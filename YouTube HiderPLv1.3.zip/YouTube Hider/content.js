let totalHiddenCount = 0;

/**
 * Potwierdzona, działająca funkcja do obliczania rangi czasowej.
 * Zawiera słowa kluczowe dla obu języków.
 * ZAKTUALIZOWANO: Używa nowego selektora metadanych.
 */
function getItemRank(videoItem) {
    if (!videoItem) return 999999999;
    // ZMIANA: Zaktualizowano selektor, aby pasował do nowoczesnego UI YouTube
    const metadataElement = videoItem.querySelector('.yt-lockup-metadata-view-model__metadata .yt-content-metadata-view-model--medium-text:last-child');
    if (!metadataElement) return 999999999;
    const text = metadataElement.textContent.toLowerCase();
    const timeUnits = {
        'minute': 1, 'hour': 60, 'day': 1440, 'week': 10080, 'month': 43200, 'year': 525600,
        'minutę': 1, 'minuty': 1, 'minut': 1,
        'godzinę': 60, 'godziny': 60, 'godzin': 60,
        'dzień': 1440, 'dni': 1440,
        'tydzień': 10080, 'tygodnie': 10080, 'tygodni': 10080,
        'miesiąc': 43200, 'miesiące': 43200, 'miesięcy': 43200,
        'rok': 525600, 'lata': 525600, 'lat': 525600
    };
    let rank = 950000000; // Domyślna wartość dla "Na żywo", "Premiera"
    for (const unit in timeUnits) {
        const index = text.lastIndexOf(unit);
        if (index > -1) {
            const textBefore = text.substring(0, index);
            const numbers = textBefore.match(/\d+/g);
            if (numbers) {
                const value = parseInt(numbers[numbers.length - 1], 10);
                rank = value * timeUnits[unit];
                return rank;
            }
        }
    }
    return rank;
}

/**
 * Główna funkcja, która filtruje i sortuje filmy za pomocą stylów CSS.
 * ZAKTUALIZOWANO: Używa nowego selektora metadanych.
 */
function processGridItems() {
    const gridItems = document.querySelectorAll('ytd-rich-item-renderer');
    if (gridItems.length === 0) return;
    console.log(`--- Przetwarzam ${gridItems.length} elementów metodą sortowania wizualnego ---`);

    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], function (result) {
        const pluginEnabled = result.pluginEnabled !== false;
        let hiddenCount = 0;

        // Resetowanie stylów, jeśli wtyczka jest wyłączona
        if (!pluginEnabled) {
            if (document.body.hasAttribute('data-youtube-hider-active')) {
                gridItems.forEach(item => {
                    item.style.display = '';
                    item.style.order = '';
                });
                document.body.removeAttribute('data-youtube-hider-active');
                console.log("Wtyczka wyłączona. Zresetowano style.");
            }
            chrome.runtime.sendMessage({ action: 'updateBadge', count: 0 });
            return;
        }
        document.body.setAttribute('data-youtube-hider-active', 'true');

        const keywordSettings = result.keywordSettings || {};
        const activeKeywords = Object.keys(keywordSettings).filter(keyword => keywordSettings[keyword]);

        gridItems.forEach(item => {
            // KROK 1: Sprawdź, czy ukryć element
            let shouldHide = false;
            // ZMIANA: Zaktualizowano selektor i uproszczono logikę sprawdzania
            const metadataElement = item.querySelector('.yt-lockup-metadata-view-model__metadata .yt-content-metadata-view-model--medium-text:last-child');
            
            if (metadataElement) {
                const textContent = metadataElement.textContent.toLowerCase();
                if (activeKeywords.some(keyword => textContent.includes(keyword.toLowerCase()))) {
                    shouldHide = true;
                }
            }

            if (shouldHide) {
                item.style.display = 'none';
                item.style.order = ''; // Usuń order, jeśli ukryty
                hiddenCount++;
            } else {
                // KROK 2: Jeśli nie ukryty, ustaw jego wizualną kolejność
                item.style.display = '';
                const rank = getItemRank(item);
                item.style.order = rank;
            }
        });

        console.log(`Przetwarzanie zakończone. Ukryto: ${hiddenCount}`);
        chrome.runtime.sendMessage({ action: 'updateBadge', count: hiddenCount });
    });
}

const observer = new MutationObserver(function (mutations) {
    const newContentAdded = mutations.some(m => m.addedNodes.length > 0);
    if (newContentAdded) {
        console.log('Wykryto nową zawartość, ponowne przetwarzanie siatki...');
        clearTimeout(window.processTimer);
        window.processTimer = setTimeout(processGridItems, 750);
    }
});

function initialize() {
    const checkInterval = setInterval(() => {
        const gridContents = document.querySelector('ytd-rich-grid-renderer #contents');
        if (gridContents && gridContents.children.length > 0) {
            clearInterval(checkInterval);
            console.log('Siatka gotowa. Inicjalizuję YouTube Hider.');
            processGridItems();
            observer.observe(gridContents, { childList: true, subtree: true });
        }
    }, 500);
}

window.addEventListener('load', initialize);
chrome.runtime.onMessage.addListener(function (request) {
    if (request.action === 'refresh') {
        location.reload();
    }
});