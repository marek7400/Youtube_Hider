const SCROLL_TICK_MS = 600; 
const MAX_STALE_ROUNDS = 12; 
const TARGET_VISIBLE_VIDEOS = 300; 

const keywords = ['minut', 'godzin', 'dzień', 'dni', 'tydzień', 'tygodni', 'tygodnie', 'miesiąc', 'miesięcy', 'rok', 'lat'];

let pluginEnabled = true;
let keywordSettings = {};
let scroll = { running: false, id: 0, lastCount: 0, stale: 0, exhausted: false };
let globalVisibleCount = 0; 
let mainInterval;

function isContextValid() {
    try {
        return !!chrome.runtime.id;
    } catch (e) {
        return false;
    }
}

try {
    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], (res) => {
        if (res.pluginEnabled !== undefined) pluginEnabled = res.pluginEnabled;
        if (res.keywordSettings !== undefined) keywordSettings = res.keywordSettings;
    });

    chrome.storage.onChanged.addListener((changes) => {
        if (changes.pluginEnabled) pluginEnabled = changes.pluginEnabled.newValue;
        if (changes.keywordSettings) keywordSettings = changes.keywordSettings.newValue;
        applyHider();
    });
} catch (e) {}

function isAllowedPath() {
    const p = window.location.pathname;
    return p === '/' || p === '/feed/subscriptions';
}

function isLiveVideo(item) {
    if (item.querySelector('[overlay-style="LIVE"], [overlay-style="SHORTS"], [overlay-style="UPCOMING"]')) return true;
    if (item.querySelector('ytd-playlist-thumbnail')) return true; 
    return false;
}

function getSeconds(item) {
    if (isLiveVideo(item)) return -1; 

    const rawText = (item.textContent || '').toLowerCase();
    const ariaLabel = item.querySelector('#video-title')?.getAttribute('aria-label') || '';
    const fullText = rawText + ' ' + ariaLabel.toLowerCase();

    const unitMap = { 'sek': 1, 'min': 60, 'godz': 3600, 'wczoraj': 86400, 'dzie': 86400, 'dni': 86400, 'tyg': 604800, 'mie': 2592000, 'rok': 31536000, 'lat': 31536000 };
    
    for (let key in unitMap) {
        let regex = new RegExp('(?:(\\d+)\\s+)?' + key + '[a-ząćęłńóśźż.]*\\s*(?:temu|ago)', 'i');
        let match = fullText.match(regex);
        if (match) {
            return (match[1] ? parseInt(match[1], 10) : 1) * unitMap[key];
        }
    }
    
    return -1; 
}

function applyHider() {
    if (!isContextValid()) {
        if (mainInterval) clearInterval(mainInterval);
        return;
    }

    if (!isAllowedPath()) return;
    const grid = document.querySelector('ytd-rich-grid-renderer > #contents');
    if (!grid) return;

    const items = grid.querySelectorAll('ytd-rich-item-renderer');
    let hiddenCnt = 0, visibleCnt = 0;
    
    // Rejestr widzianych filmów na obecnej liście
    const seenVideos = new Set();

    for (let i = 0; i < items.length; i++) {
        let item = items[i];
        let isDuplicate = false;
        let videoId = null;

        // 1. BEZBŁĘDNE wyciąganie ID (Regex) z jakiegokolwiek linku przypisanego do filmu
        let links = item.querySelectorAll('a[href*="/watch?v="]');
        for (let j = 0; j < links.length; j++) {
            let href = links[j].getAttribute('href') || links[j].href || '';
            let match = href.match(/[?&]v=([^&]+)/);
            if (match && match[1]) {
                videoId = match[1];
                break;
            }
        }

        // 2. FALLBACK (Opcja zapasowa): Jeśli YouTube zablokuje URL, szukaj powtórek po tytułach
        let titleKey = null;
        if (!videoId) {
            let titleEl = item.querySelector('#video-title');
            if (titleEl) {
                let t = (titleEl.textContent || titleEl.getAttribute('aria-label') || "").trim().toLowerCase();
                if (t.length > 10) titleKey = t;
            }
        }

        // 3. WERYFIKACJA DUPLIKATÓW
        if (videoId) {
            if (seenVideos.has(videoId)) {
                isDuplicate = true;
            } else {
                seenVideos.add(videoId);
            }
        } else if (titleKey) {
            if (seenVideos.has(titleKey)) {
                isDuplicate = true;
            } else {
                seenVideos.add(titleKey);
            }
        }

        let secs = getSeconds(item);
        
        // Film zostaje oznaczony do ukrycia jeśli to Live/Short ALBO Duplikat
        let hide = (secs === -1) || isDuplicate;

        if (!hide && pluginEnabled) {
            for (let j = 0; j < keywords.length; j++) {
                let kw = keywords[j];
                if (keywordSettings[kw]) {
                    if (item.textContent.toLowerCase().includes(kw.substring(0, 3).toLowerCase())) { 
                        hide = true; 
                        break; 
                    }
                }
            }
        }

        if (hide) {
            item.classList.add('yth-hidden');
            // Zabezpieczenie dodatkowe prosto w style elementu (eliminuje konflikty CSS)
            item.style.setProperty('display', 'none', 'important');
            hiddenCnt++;
        } else {
            item.classList.remove('yth-hidden');
            item.style.removeProperty('display');
            item.style.setProperty('order', String(secs), 'important');
            visibleCnt++;
        }
    }

    globalVisibleCount = visibleCnt;
    let badgeText = pluginEnabled ? (hiddenCnt > 0 ? String(hiddenCnt) : 'ON') : 'OFF';

    try {
        chrome.runtime.sendMessage({ action: 'updateBadge', text: badgeText });
    } catch (e) {}

    if (pluginEnabled && globalVisibleCount < TARGET_VISIBLE_VIDEOS && !scroll.running && !scroll.exhausted) {
        startAutoLoad();
    }
}

function startAutoLoad() {
    if (!isContextValid() || !isAllowedPath() || scroll.running) return;
    scroll.running = true;
    scroll.id++;
    scroll.stale = 0;
    scroll.lastCount = document.querySelectorAll('ytd-rich-item-renderer').length;
    scrollStep(scroll.id);
}

function scrollStep(id) {
    if (!isContextValid() || id !== scroll.id || !scroll.running) return;

    if (globalVisibleCount >= TARGET_VISIBLE_VIDEOS) {
        scroll.running = false;
        window.scrollTo(0, 0); 
        return;
    }

    let items = document.querySelectorAll('ytd-rich-item-renderer');
    
    const loader = document.querySelector('ytd-continuation-item-renderer');
    if (loader) {
        loader.scrollIntoView(false);
    } else {
        window.scrollTo(0, document.documentElement.scrollHeight);
    }

    window.scrollBy(0, -50);
    setTimeout(() => {
        if (!isContextValid()) return;
        window.scrollBy(0, 50);
    }, 50);

    if (items.length > scroll.lastCount) {
        scroll.lastCount = items.length;
        scroll.stale = 0;
        applyHider(); 
    } else {
        scroll.stale++;
    }

    if (scroll.stale >= MAX_STALE_ROUNDS) {
        scroll.running = false;
        scroll.exhausted = true; 
        window.scrollTo(0, 0);
        return;
    }

    setTimeout(() => scrollStep(id), SCROLL_TICK_MS);
}

mainInterval = setInterval(applyHider, 1500);

window.addEventListener('yt-navigate-finish', () => {
    if (!isContextValid()) return;
    scroll.running = false; 
    scroll.exhausted = false; 
    setTimeout(startAutoLoad, 1000);
});

setTimeout(startAutoLoad, 1500);