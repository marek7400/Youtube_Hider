// content.js

/**
 * Calculates time into minutes for sorting purposes.
 * Returns -1 if no publication time info is found (e.g., Live streams, Ads).
 */
function calculateRank(item) {
    const text = item.textContent.toLowerCase();
    
    // 1. Check if it's Sponsored or an Ad (they usually lack standard upload time)
    if (item.querySelector('#ad-badge, .ytd-ad-slot-renderer') || text.includes('sponsored') || text.includes('ad')) {
        return -1;
    }

    // 2. Look for text indicating time ("ago")
    // Updated selectors for the new YouTube layout
    const metadataSelectors = [
        '#metadata-line span.inline-metadata-item',
        '#metadata-line span',
        '.yt-core-attributed-string', // NEW: current standard for rendering text on YT
        '.yt-lockup-metadata-view-model__metadata span',
        '.yt-content-metadata-view-model__metadata-row span'
    ];
    
    let timeText = "";
    
    // Search inside specific HTML tags first
    for (const selector of metadataSelectors) {
        const elements = item.querySelectorAll(selector);
        for (const el of elements) {
            const txt = el.textContent.toLowerCase();
            // Look for the phrase suggesting publication time
            if (txt.includes('ago')) {
                timeText = txt;
                break;
            }
        }
        if (timeText) break;
    }

    // 3. FALLBACK - If YouTube changes tags again, search all visible text
    if (!timeText) {
        const visibleText = item.innerText || "";
        const lines = visibleText.toLowerCase().split('\n');
        for (const line of lines) {
            if (line.includes('ago')) {
                timeText = line;
                break;
            }
        }
    }

    // IF NO TIME FOUND -> Return -1 (to be hidden)
    if (!timeText) return -1;

    // Supported English time units
    const timeUnits = {
        'second': 1, 'seconds': 1, // Usually fresh uploads, treated as 1 min to stay at top
        'minute': 1, 'minutes': 1, 'min': 1, 'mins': 1,
        'hour': 60, 'hours': 60, 'hr': 60, 'hrs': 60,
        'day': 1440, 'days': 1440,
        'week': 10080, 'weeks': 10080,
        'month': 43200, 'months': 43200, 'mo': 43200, 'mos': 43200,
        'year': 525600, 'years': 525600, 'yr': 525600, 'yrs': 525600
    };

    for (const unit in timeUnits) {
        if (timeText.includes(unit)) {
            const match = timeText.match(/\d+/);
            const value = match ? parseInt(match[0], 10) : 1; // e.g. "an hour ago" -> treats as 1
            return value * timeUnits[unit];
        }
    }

    return -1; // If time unit is not supported
}

function processYouTubeHider() {
    const gridContainer = document.querySelector('ytd-rich-grid-renderer #contents');
    if (!gridContainer) return;

    // Force Flexbox for correct 'order' sorting
    gridContainer.style.display = 'flex';
    gridContainer.style.flexWrap = 'wrap';

    const items = gridContainer.querySelectorAll('ytd-rich-item-renderer, ytd-rich-section-renderer');

    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], function (result) {
        const isEnabled = result.pluginEnabled !== false;
        let hiddenCount = 0;

        // If plugin is disabled, reset all styles
        if (!isEnabled) {
            gridContainer.style.display = '';
            items.forEach(item => {
                item.style.display = '';
                item.style.order = '';
                item.style.width = '';
            });
            return;
        }

        const keywordSettings = result.keywordSettings || {};
        const activeKeywords = Object.keys(keywordSettings).filter(k => keywordSettings[k]);
        const itemsPerRow = getComputedStyle(gridContainer).getPropertyValue('--ytd-rich-grid-items-per-row') || 4;

        items.forEach(item => {
            const textContent = item.textContent.toLowerCase();
            const rank = calculateRank(item);
            
            let shouldHide = false;

            // STEP 1: Hide if there is no upload time (rank === -1)
            if (rank === -1) {
                shouldHide = true;
            } 
            // STEP 2: Hide if it matches keywords selected by the user
            else if (activeKeywords.some(kw => textContent.includes(kw.toLowerCase()))) {
                shouldHide = true;
            }

            if (shouldHide) {
                item.style.display = 'none';
                hiddenCount++;
            } else {
                // Display and sort
                item.style.display = 'block';
                item.style.width = `calc(100% / ${itemsPerRow} - 16px)`;
                item.style.margin = '0 8px 24px 8px';
                item.style.order = rank; // Sort by age
            }
        });

        // Send info to background.js to update the extension badge
        chrome.runtime.sendMessage({ action: 'updateBadge', count: hiddenCount });
    });
}

// Mutation Observer (for dynamic loading when scrolling)
const observer = new MutationObserver((mutations) => {
    if (mutations.some(m => m.addedNodes.length > 0)) {
        clearTimeout(window.hiderTimer);
        window.hiderTimer = setTimeout(processYouTubeHider, 400);
    }
});

function init() {
    const container = document.querySelector('ytd-rich-grid-renderer #contents');
    if (container) {
        processYouTubeHider();
        observer.observe(container, { childList: true });
    } else {
        setTimeout(init, 1000);
    }
}

// Initialize script on first load and on YouTube page navigation
init();
window.addEventListener('yt-navigate-finish', init);

// Listen for refresh messages from popup
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'refresh') processYouTubeHider();
});