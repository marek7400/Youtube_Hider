
/**
 * Potwierdzona, działająca funkcja do obliczania rangi czasowej.
 * ZAKTUALIZOWANO: Używa nowego selektora i tylko angielskich jednostek czasu.
 */
function getItemRank(videoItem) {
    if (!videoItem) return 999999999;
    // ZMIANA: Zaktualizowano selektor, aby pasował do nowoczesnego UI YouTube
    const metadataElement = videoItem.querySelector('yt-content-metadata-view-model.yt-content-metadata-view-model-wiz.yt-content-metadata-view-model-wiz--medium-text');
    if (!metadataElement) return 999999999;
    const text = metadataElement.textContent.toLowerCase();
    
    // ZMIANA: Usunięto polskie jednostki, pozostawiono tylko angielskie.
    const timeUnits = {
        'minute': 1, 'minutes': 1, 
        'hour': 60, 'hours': 60, 
        'day': 1440, 'days': 1440, 
        'week': 10080, 'weeks': 10080, 
        'month': 43200, 'months': 43200, 
        'year': 525600, 'years': 525600
    };

    let rank = 950000000; // Domyślna wartość dla "Live", "Premiere"
    for (const unit in timeUnits) {
        const index = text.lastIndexOf(unit);
        if (index > -1) {
            const textBefore = text.substring(0, index);
            const numbers = textBefore.match(/\d+/g);
            if (numbers) {
                const value = parseInt(numbers[numbers.length - 1], 10);
                rank = value * timeUnits[unit];
                return rank;
            }
        }
    }
    return rank;
}

/**
 * Główna funkcja, która filtruje i sortuje filmy za pomocą stylów CSS.
 * ZAKTUALIZOWANO: Używa nowego selektora metadanych.
 */
function processGridItems() {
    const gridItems = document.querySelectorAll('ytd-rich-item-renderer');
    if (gridItems.length === 0) return;
    console.log(`--- Processing ${gridItems.length} items with Visual Sort ---`);

    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], function (result) {
        const pluginEnabled = result.pluginEnabled !== false;
        let hiddenCount = 0;

        // Resetowanie stylów, jeśli wtyczka jest wyłączona
        if (!pluginEnabled) {
            if (document.body.hasAttribute('data-youtube-hider-active')) {
                gridItems.forEach(item => {
                    item.style.display = '';
                    item.style.order = '';
                });
                document.body.removeAttribute('data-youtube-hider-active');
                console.log("Plugin disabled. Styles reset.");
            }
            chrome.runtime.sendMessage({ action: 'updateBadge', count: 0 });
            return;
        }
        document.body.setAttribute('data-youtube-hider-active', 'true');

        const keywordSettings = result.keywordSettings || {};
        const activeKeywords = Object.keys(keywordSettings).filter(keyword => keywordSettings[keyword]);

        gridItems.forEach(item => {
            // KROK 1: Sprawdź, czy ukryć element
            let shouldHide = false;
            // ZMIANA: Zaktualizowano selektor. Słowo 'Sponsored' jest teraz częścią tych samych metadanych.
            const metadataElement = item.querySelector('yt-content-metadata-view-model.yt-content-metadata-view-model-wiz.yt-content-metadata-view-model-wiz--medium-text');
            
            if (metadataElement) {
                const textContent = metadataElement.textContent.toLowerCase();
                if (activeKeywords.some(keyword => textContent.includes(keyword.toLowerCase()))) {
                    shouldHide = true;
                }
            }

            if (shouldHide) {
                item.style.display = 'none';
                item.style.order = ''; // Usuń order, jeśli ukryty
                hiddenCount++;
            } else {
                // KROK 2: Jeśli nie ukryty, ustaw jego wizualną kolejność
                item.style.display = '';
                const rank = getItemRank(item);
                item.style.order = rank;
            }
        });

        console.log(`Processing complete. Hidden: ${hiddenCount}`);
        chrome.runtime.sendMessage({ action: 'updateBadge', count: hiddenCount });
    });
}

const observer = new MutationObserver(function (mutations) {
    const newContentAdded = mutations.some(m => m.addedNodes.length > 0);
    if (newContentAdded) {
        console.log('New content detected, re-processing grid...');
        clearTimeout(window.processTimer);
        window.processTimer = setTimeout(processGridItems, 750);
    }
});

function initialize() {
    const checkInterval = setInterval(() => {
        const gridContents = document.querySelector('ytd-rich-grid-renderer #contents');
        if (gridContents && gridContents.children.length > 0) {
            clearInterval(checkInterval);
            console.log('Grid ready. Initializing YouTube Hider.');
            processGridItems();
            observer.observe(gridContents, { childList: true, subtree: true });
        }
    }, 500);
}

window.addEventListener('load', initialize);
chrome.runtime.onMessage.addListener(function (request) {
    if (request.action === 'refresh') {
        location.reload();
    }
});