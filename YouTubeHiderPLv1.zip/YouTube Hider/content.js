// content.js

let totalHiddenCount = 0;

function hideClosestRichItem() {
    console.log('hideClosestRichItem function called');
    chrome.storage.local.get(['pluginEnabled', 'keywordSettings'], function (result) {
        console.log('Plugin settings:', result);
        const pluginEnabled = result.pluginEnabled !== false;
        if (!pluginEnabled) {
            console.log('Plugin is disabled');
            // Jeśli plugin jest wyłączony, upewnijmy się, że plakietka jest pusta
            chrome.runtime.sendMessage({ action: 'updateBadge', count: 0 });
            return;
        }

        const keywordSettings = result.keywordSettings || {};
        const activeKeywords = Object.keys(keywordSettings).filter(keyword => keywordSettings[keyword]);
        console.log('Active keywords:', activeKeywords);

        let hiddenInThisRun = 0;

        // Główna logika ukrywania - ytd-rich-item-renderer
        const videoItems = document.querySelectorAll('ytd-rich-item-renderer');
        console.log('Found video items:', videoItems.length);
        videoItems.forEach(item => {
            // Unikaj ponownego sprawdzania już ukrytych elementów
            if (item.style.display === 'none') {
                return;
            }
            const timeElement = item.querySelector('#metadata-line');
            if (timeElement) {
                const timeText = timeElement.textContent.toLowerCase();
                if (activeKeywords.some(keyword => timeText.includes(keyword.toLowerCase()))) {
                    console.log('Matching time found, hiding item:', timeText);
                    item.style.display = 'none';
                    hiddenInThisRun++;
                }
            }
        });

        // Stara metoda (zostawiona jako awaryjna, upewnijmy się, że nie liczy podwójnie)
        const targetElements = document.querySelectorAll('span.ytd-video-meta-block.style-scope.inline-metadata-item:nth-of-type(2)');
        console.log('Found target elements (old method):', targetElements.length);
        targetElements.forEach(element => {
            const closestRichItem = element.closest('.ytd-rich-grid-row.style-scope');
            if (closestRichItem && closestRichItem.style.display !== 'none') {
                const textContent = element.textContent.toLowerCase();
                if (activeKeywords.some(keyword => textContent.includes(keyword.toLowerCase()))) {
                    console.log('Keyword found (old method), removing element:', textContent);
                    closestRichItem.style.display = 'none'; // Zmieniamy remove() na display, aby uniknąć błędów
                    hiddenInThisRun++;
                }
            }
        });

        if (hiddenInThisRun > 0) {
            totalHiddenCount += hiddenInThisRun;
            console.log(`Hid ${hiddenInThisRun} items in this run. Total hidden: ${totalHiddenCount}`);
        }

        // Wyślij wiadomość do background script, aby zaktualizować plakietkę
        chrome.runtime.sendMessage({ action: 'updateBadge', count: totalHiddenCount });
    });
}

// Wywołaj funkcję po załadowaniu strony
window.addEventListener('load', function () {
    console.log('Page loaded, calling hideClosestRichItem');
    hideClosestRichItem();

    // Wywołaj funkcję po kliknięciu na element ".yt-chip-cloud-chip-renderer.style-scope"
    document.addEventListener('click', function (event) {
        if (event.target.matches('.yt-chip-cloud-chip-renderer.style-scope')) {
            console.log('Chip clicked, calling hideClosestRichItem');
            // Poczekaj chwilę, aż YouTube załaduje nową zawartość
            setTimeout(hideClosestRichItem, 500);
        }
    });

    // Obserwator mutacji dla nowych elementów
    var observer = new MutationObserver(function (mutations) {
        let needsUpdate = false;
        mutations.forEach(function (mutation) {
            if (mutation.type === 'childList') {
                mutation.addedNodes.forEach(function (node) {
                    if (node.nodeType === 1 && (node.matches('ytd-rich-item-renderer') || node.querySelector('ytd-rich-item-renderer'))) {
                        needsUpdate = true;
                    }
                });
            }
        });
        if(needsUpdate) {
            console.log('New video items potentially added, calling hideClosestRichItem');
            // Używamy debounce, aby nie wywoływać funkcji zbyt często
            clearTimeout(window.hideTimer);
            window.hideTimer = setTimeout(hideClosestRichItem, 300);
        }
    });

    // Konfiguracja obserwatora mutacji
    var config = { childList: true, subtree: true };
    // Rozpocznij obserwację na głównym kontenerze z treścią, to bardziej wydajne
    const contentContainer = document.querySelector('ytd-page-manager');
    if (contentContainer) {
        observer.observe(contentContainer, config);
    } else {
        observer.observe(document.body, config); // Fallback
    }


    // Nasłuchuj komunikatów od popup.js
    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
        if (request.action === 'refresh') {
            console.log('Refresh request received, reloading page');
            location.reload(); // Odśwież stronę po zmianie ustawień
        }
    });
});

// Dodatkowa funkcja do debugowania - możesz ją wywołać z konsoli przeglądarki
function debugSelectors() {
    console.log('Debugging selectors:');
    console.log('ytd-rich-item-renderer count:', document.querySelectorAll('ytd-rich-item-renderer').length);
    console.log('span.ytd-video-meta-block.style-scope.inline-metadata-item:nth-of-type(2) count:',
        document.querySelectorAll('span.ytd-video-meta-block.style-scope.inline-metadata-item:nth-of-type(2)').length);
    console.log('#metadata-line count:', document.querySelectorAll('#metadata-line').length);
}

// Wywołaj debugSelectors po załadowaniu strony
window.addEventListener('load', debugSelectors);